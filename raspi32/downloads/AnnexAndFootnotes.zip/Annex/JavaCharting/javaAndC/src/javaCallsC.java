import info.monitorenter.gui.chart.Chart2D;
import info.monitorenter.gui.chart.ITrace2D;
import info.monitorenter.gui.chart.traces.Trace2DSimple;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.swing.BoxLayout;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class javaCallsC {

	private static final int NUMBER_OF_DEVICES = 8;

	public static void main(String[] args) throws Exception {
//		ProcessBuilder pb = new ProcessBuilder("ls");
		ProcessBuilder pb = new ProcessBuilder("./adSequencePolling", "--java_graph");
		pb.redirectErrorStream(true);

		Process p = pb.start();

		BufferedReader reader = new BufferedReader(new InputStreamReader(
				p.getInputStream()));

		printChart(reader);

		p.waitFor();
		System.out.println("Ok!");
		reader.close();
	}

	private static void printChart(BufferedReader reader) throws IOException {
		
		List<double[]> doubleValues = new ArrayList<double[]>();
		// Fill the vector with zeroes
		double[] zeroes = new double[NUMBER_OF_DEVICES];
		for (int i = 0; i < zeroes.length; i++) {
			zeroes[i] = 0.0;
		}
		for (int i = 100; i >= 0; i--) {
			doubleValues.add(zeroes);
		}
		
		ITrace2D[] traces = new Trace2DSimple[NUMBER_OF_DEVICES];
		for (int i = 0; i < traces.length; i++) {
			traces[i] = new Trace2DSimple("IN"+i);
		}
		Chart2D[] charts = new Chart2D[NUMBER_OF_DEVICES];
		for (int i=0; i<charts.length; i++) {
			charts[i] = new Chart2D();
			charts[i].addTrace(traces[i]);
		}
		
		// Create the pannel of charts
		JPanel panel = new JPanel();
		panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
		
		for (int i = 0; i < charts.length; i++) {
			charts[i].setSize(100, 100);
			panel.add(charts[i]);		// TODO
		}

		// Make the chart visible visible:
		// Create a frame.
		JFrame frame = new JFrame("MinimalStaticChart");
		// add the charts to the frame:
		frame.setContentPane(panel);
		
		frame.setSize(1200, 900);
		// Enable the termination button [cross on the upper right edge]:
		frame.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
		});
		// aaaaand there we go!
		frame.setVisible(true);

		String line;
		while ((line = reader.readLine()) != null) {
			// use the string to parse new integers
			String[] stringIntegersPlusEmptyHead = line.split(",");
			String[] stringIntegers = new String[stringIntegersPlusEmptyHead.length-1];
			for (int i = 0; i < stringIntegers.length; i++) {
				stringIntegers[i] = stringIntegersPlusEmptyHead[i+1];
			}
			
			if (stringIntegers.length != NUMBER_OF_DEVICES) {
				throw new IllegalArgumentException(
						"Output of foreign process does not match expected number " +
						"of devices. Expected" + NUMBER_OF_DEVICES + " but was " +
						stringIntegers.length + ". Parsing output: " +
						Arrays.toString(stringIntegers));
			}
			
			double[] newValues = new double[stringIntegers.length];
			for (int i=0; i<stringIntegers.length; i++) {
				newValues[i] = Double.parseDouble(stringIntegers[i]);
			}
			doubleValues.remove(0);
			doubleValues.add(newValues);
			
			// update all traces
			for (int i = 0; i < traces.length; i++) {
				traces[i].removeAllPoints();
				for (int j = 0; j < 100; j++) {
					traces[i].addPoint(j, doubleValues.get(j)[i]);
				}
			}
			
			//update all charts
			for (int i = 0; i < charts.length; i++) {				
				charts[i].removeAllTraces();
				charts[i].addTrace(traces[i]);
			}
		}
	}
}
