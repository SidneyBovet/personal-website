Sidney Bovet (sidney.bovet@epfl.ch) - EPFL - LAP - 2013

This folder contains various testing programs.

MISO on MOSI makes the device talk to itself. It just sends a word through MOSI (master in slave out) and displays it.

temperature test uses the AD converter's internal temperature sensor to easily verify if SPI talking works.

adSequencePolling is the final version described in the project report.
