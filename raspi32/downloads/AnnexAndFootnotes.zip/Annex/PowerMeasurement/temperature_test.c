#include <wiringPiSPI.h>
#include <stdio.h>
#include <stdlib.h>

#include <unistd.h>


#define BUFFER_SIZE 2

int wiringPiSPISetup(int channel, int speed);
int wiringPiSPIDataRW(int channel, unsigned char* data, int size);

int main(int argc, char** argv)
{
	/* setting up SPI */
	if(wiringPiSPISetup(0,1000000)<0)
	{
		printf("Error while initiating SPI.\n");
	}
	
	// declare value buffer
	unsigned char* buffer = calloc(BUFFER_SIZE, sizeof(unsigned char));

	while (1)
	{
		//printf("\n\033[F\033[J");
		// the following polls the temp sensor
		buffer[0] = ('X' << 1)|1;
		buffer[1] = ' ';
		//this polls device IN7
		//buffer[0] = 255;
		//buffer[1] = 36;

		wiringPiSPIDataRW(0,buffer,BUFFER_SIZE);

		/*
		int convertedResult = 0;
		convertedResult += (buffer[0] << 8)+buffer[1];
		printf("%d", convertedResult);
		//*/

		//*
		printf("0x");
		int j;
		for (j = 0; j < BUFFER_SIZE; j++)
		{
			printf("%02x",buffer[j]);
		}
		//*/
		printf("\n");
		fflush(stdout);
		sleep(1);

		printf("\033[F\033[J");
	}

	return EXIT_SUCCESS;
}
