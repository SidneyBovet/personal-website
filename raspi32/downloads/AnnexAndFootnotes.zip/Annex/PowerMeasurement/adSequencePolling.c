 /*
 * Sidney Bovet - EPFL - LAP & LSR
 *
 * A/D converter SPI talking
 *
 */

#include <wiringPiSPI.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <unistd.h>
#include <time.h>

#define BUFFER_SIZE 2
#define AD_CONVERTER_ZERO_OFFSET 863
#define AD_CONVERTER_ONE_AMPERE_VALUE 7744
#define NUMBER_OF_DEVICES 8

typedef void (*printing_function_ptr)(const unsigned char* buffer, int scannedDevice, FILE* out);

int wiringPiSPISetup(int channel, int speed);
int wiringPiSPIDataRW(int channel, unsigned char* data, int size);

void printHelp();
void printHeader();
void printConsoleValue(const unsigned char* buffer, int scannedDevice, FILE* out);
void printJavaGraphValue(const unsigned char* buffer, int scannedDevice, FILE* out);
void printToCsvFile(const unsigned char* buffer, int scannedDevice, FILE* out);
printing_function_ptr parseArgs(size_t argc, char** argv);

int main(int argc, char** argv)
{
	// Arguments parsing (determines output format)
	void (*printingFunction)(const unsigned char* buffer, int scannedDevice, FILE* out);
	printingFunction = parseArgs(argc, argv);
	if (NULL == printingFunction)
	{
		return EXIT_FAILURE;
	}

	/* setting up SPI at 1 MHz */
	if(wiringPiSPISetup(0,1000000)<0)
	{
		printf("Error while initiating SPI.\n");
	}

	FILE* outputStream = stdout;
	unsigned char* buffer = calloc(BUFFER_SIZE, sizeof(unsigned char));
	int currentDeviceScanned = 0;
	buffer[0] = 241;
	buffer[1] = 36;

	if (printingFunction == printConsoleValue)
	{
		printHeader();
	}
	else if (printingFunction == printToCsvFile && argc == 3)
	{
		outputStream = fopen(argv[2], "w+");
		if (NULL == outputStream)
		{
			printf("Error while opening/creating file %s, falling back to stdout.", argv[2]);
			outputStream = stdout;
		}
		else
		{
			// then we print the first line of the file, with the titles
			int i;
			for(i=0; i<NUMBER_OF_DEVICES; ++i)
			{
				fprintf(outputStream, "IN%d",i);
				if (i==NUMBER_OF_DEVICES-1)
					fprintf(outputStream,"\n");
				else
					fprintf(outputStream,",");
			}
		}
	}

	while (1)
	{
		buffer[0] = 241 + 2 * ( (currentDeviceScanned+2)%8);
		buffer[1] = 36;
		wiringPiSPIDataRW(0,buffer,BUFFER_SIZE);
		
		currentDeviceScanned = (currentDeviceScanned + 1) % NUMBER_OF_DEVICES;
		
		// call the printing function defined by the arguments
		(*printingFunction)(buffer, currentDeviceScanned, outputStream);
		
		// give the converter some time to process
		struct timespec temps;
		temps.tv_sec = 0;
		temps.tv_nsec = 500; // 500 ns
		nanosleep(&temps, NULL);
	}

	return EXIT_SUCCESS;
}

double convertHexToPower(const unsigned char* buffer)
{
	//// HEX to DEC conversion ////
	int convertedResult = 0;
	convertedResult += (buffer[0] << 8)+buffer[1];

	//// Normalize the result (due to offsets from the converter) ////
	double normalizedResult = convertedResult - AD_CONVERTER_ZERO_OFFSET;
	normalizedResult = normalizedResult / (AD_CONVERTER_ONE_AMPERE_VALUE - AD_CONVERTER_ZERO_OFFSET);

	//// Compute power with known voltage ////
	double powerConsumption = normalizedResult * 5.06; // measured voltage

	return powerConsumption;
}

void printConsoleValue(const unsigned char* buffer, int currentDeviceScanned, FILE* stream)
{
	double powerConsumption = convertHexToPower(buffer);

	printf("\t%3.2lf", powerConsumption);
	fflush(stdout);

	if (0 == currentDeviceScanned)
	{
		struct timespec temps;
		temps.tv_sec = 0;
		temps.tv_nsec = 500000000; // 0.5 seconds
		nanosleep(&temps, NULL); // to let the user read
		printf("\n\033[F\033[J");
	}
}

void printJavaGraphValue(const unsigned char* buffer, int currentDeviceScanned, FILE* stream)
{
	double powerConsumption = convertHexToPower(buffer);

	printf(",%lf", powerConsumption);
	fflush(stdout);

	if (0 == currentDeviceScanned)
	{
		struct timespec temps;
		temps.tv_sec = 3; // in second
		temps.tv_nsec = 0; // in ns
		nanosleep(&temps, NULL); // in order for Java to print the values
		printf("\n");
	}
}

void printToCsvFile(const unsigned char* buffer, int currentDeviceScanned, FILE* stream)
{
	double powerConsumption = convertHexToPower(buffer);

	fprintf(stream,"%lf", powerConsumption);

	if (0 == currentDeviceScanned)
	{
		fprintf(stream,"\n");

		struct timespec temps;
		temps.tv_sec = 0;
		temps.tv_nsec = 100000000; // 0.1 seconds
		nanosleep(&temps, NULL); // to avoid huge log file
	}
	else
	{
		fprintf(stream,",");
	}

}

void printHeader()
{
	printf("\t\t\t--- Power consumption of nodes ---\n");

	int i;
	for (i = 0; i < NUMBER_OF_DEVICES; i++)
	{
		printf("\tIN%d", i);
	}
	printf("\n");
}

printing_function_ptr parseArgs(size_t argc, char** argv)
{
	if (argc <= 1 || strcmp(argv[1],"--console") == 0)
	{
		return printConsoleValue;
	}
	else if (strcmp(argv[1],"--java_graph") == 0)
	{
		return printJavaGraphValue;
	}
	else if (strcmp(argv[1],"--help") == 0)
	{
		printHelp();
		return NULL;
	}
	else if (strcmp(argv[1],"--file") == 0 && argc >= 3)
	{
		return printToCsvFile;
	}
	else
	{
		printf("Wrong arguments. Usage:\n");
		printHelp();
		return NULL;
	}
}

void printHelp()
{
	printf("\tno argument\n");
	printf("\t\tPrints and updates the values in a human-readable manner.\n");
	printf("\t--console\n");
	printf("\t\tSame as without arguments.\n");
	printf("\t--java_graph\n");
	printf("\t\tPrints the values read, separated by commas\n");
	printf("\t\tNot intended for human use, but with the Java plotter\n");
	printf("\t--file FILENAME\n");
	printf("\t\tPrints the values read to FILE in CVS format.\n");
	printf("\t--help\n");
	printf("\t\tDisplays this help.\n");
}
