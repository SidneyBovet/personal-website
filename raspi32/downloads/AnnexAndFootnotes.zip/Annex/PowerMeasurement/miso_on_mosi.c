#include <wiringPiSPI.h>
#include <stdio.h>
#include <stdlib.h>

#define BUFFER_SIZE 2

int wiringPiSPISetup(int channel, int speed);
int wiringPiSPIDataRW(int channel, unsigned char* data, int size);

int main(int argc, char** argv)
{
	/* setting up SPI */
	if(wiringPiSPISetup(0,1000000)<0)
	{
		printf("Error while initiating SPI.\n");
	}

	/* building command word */
	unsigned char* buffer = calloc(BUFFER_SIZE, sizeof(char));
	buffer[0] = ('X' << 1) | 1;
	buffer[1] = ' ';
	
	printf("Before RW, buffer is: 0x");
	int i;
	for (i = 0; i < BUFFER_SIZE; i++)
	{
		printf("%x",buffer[i]);
	}
	printf("\n");

	/* send it and check */
	wiringPiSPIDataRW(0,buffer,BUFFER_SIZE);
	
	printf("After RW, buffer is:  0x");
	for (i = 0; i < BUFFER_SIZE; i++)
	{
		printf("%x",buffer[i]);
	}
	printf("\n");
	
	
	return EXIT_SUCCESS;
}
