#include "tcp_base.h"
#include "rpi.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>

#define M_SIZE 100

void connected(const SOCKET* sockIn, const SOCKET* sockOut);
char* read_stdin(char* buffer, size_t taille);


SOCKET getSocketOut(char* serv_ip);
SOCKET getSocketIn();

int main(int argc, char** argv)
{
	#if defined (WIN32)
		WSADATA WSAData;
        int erreur = WSAStartup(MAKEWORD(2,2), &WSAData);
    #else
        int erreur = 0;
    #endif

    // args validation + handling
    char* serverIP = calloc(16, sizeof(char));
    int lastNode = 0;

    if (argc!=3)
    {
		printf("Wrong number of arguments, typical use:\n'./node [yes/no] nextNodeIP'\n");
		return EXIT_FAILURE;
	}
	else
	{
		lastNode = strncmp(argv[1],"yes", 3);
		serverIP = argv[2];
	}
    
    //init gpio pins
    if (map_peripheral(&gpio) == -1)
	{
		printf("Failed to map phisycal GPIO registers into virtual memory space\n");
		return EXIT_FAILURE;
	}
	// this is pin number 7 (!)
	INP_GPIO(4);
	OUT_GPIO(4);

    // starting to open in/out sockets
    if(!erreur)
    {
        SOCKET sockOut;
        SOCKET sockIn;

		if (lastNode == 0)
		{
			sockOut = getSocketOut(serverIP);
			printf("Contacted by node\n");
			fflush(stdout);

			sockIn = getSocketIn();
			printf("Node contacted\n");
			fflush(stdout);

			sleep(1);
			send(sockOut, TOKEN, BUFFER_SIZE*sizeof(char), 0);
			printf("token sent!\n");
		}
		else
		{
			sockIn = getSocketIn();
			fflush(stdout);
			sleep(1);
			sockOut = getSocketOut(serverIP);
		}
		
		if (sockIn != SOCKET_ERROR && sockOut != SOCKET_ERROR)
		{
			printf("All went well, entering token managment function\n");
			connected(&sockIn, &sockOut);
		}
		else
		{
			printf("There was an error, SOCKET_ERROR=%d, sockIn=%d, sockOut=%d\n",SOCKET_ERROR,sockIn,sockOut);
		}
		
		/* Fermeture de la socket client et de la socket serveur */
		printf("Fermeture de la socket sortante\n");
		closesocket(sockOut);
		printf("Fermeture de la socket entrante\n");
		closesocket(sockIn);
		printf("Fermeture du noeud terminée\n");
        
        #if defined (WIN32)
            WSACleanup();
        #endif
    }
     fflush(stdin);
    return EXIT_SUCCESS;
}


SOCKET getSocketOut(char* serv_ip)
{
    /* Socket et contexte d'adressage du serveur */
    SOCKADDR_IN sin;
    SOCKET sock;
    
	/* Création d'une socket */
        sock = socket(AF_INET, SOCK_STREAM, 0);
        {
			serv_ip[15] = '\0';
			sin.sin_addr.s_addr = inet_addr(serv_ip);
			sin.sin_family = AF_INET;
			sin.sin_port = htons(PORT);
		}

		printf("Trying to connect to '%s:%d' as outstream...", serv_ip,PORT);

		if (connect(sock, (SOCKADDR*)&sin, sizeof(sin)) != SOCKET_ERROR)
		{
			printf(" done!\n");
			return sock;
		}
		else
		{
			perror("failed");
			return SOCKET_ERROR;
		}
}

SOCKET getSocketIn()
{
		int sock_err;
		
		// server
        SOCKET sock = socket(AF_INET, SOCK_STREAM, 0);
        SOCKADDR_IN sin;
		socklen_t recsize = sizeof(sin);
		
		// client
		SOCKET csock;
        SOCKADDR_IN csin;
		socklen_t crecsize = sizeof(sin);
        
        /* Si la socket est valide */
        if(sock != INVALID_SOCKET)
        {
            /* Configuration */
            sin.sin_addr.s_addr = htonl(INADDR_ANY);  /* Adresse IP automatique */
            sin.sin_family = AF_INET;                 /* Protocole familial (IP) */
            sin.sin_port = htons(PORT);               /* Listage du port */
            sock_err = bind(sock, (SOCKADDR*)&sin, recsize);
             
            /* Si la socket fonctionne */
            if(sock_err != SOCKET_ERROR)
            {
                /* Démarrage du listage (mode server) */
                sock_err = listen(sock, 5);
                printf("[rcver] Listage du port %d...\n", PORT);
                
                /* Si la socket fonctionne */
                if(sock_err != SOCKET_ERROR)
                {
                    /* Attente pendant laquelle le client se connecte */
					fflush(stdout);
                    csock = accept(sock, (SOCKADDR*)&csin, &crecsize);
                    printf("[rcver] Un client se connecte avec la socket %d de %s:%d\n", csock, inet_ntoa(csin.sin_addr), htons(csin.sin_port));
                    return csock;
                }
                else
                    perror("[rcver] listen");
            }
            else
                perror("[rcver] bind");
        }
        else
            perror("[rcver] socket");

		return SOCKET_ERROR;
}

void connected(const SOCKET* sockIn, const SOCKET* sockOut)
{
	char* buffer = calloc(BUFFER_SIZE+1, sizeof(char));
	strncpy(buffer, TOKEN, BUFFER_SIZE);
	buffer[BUFFER_SIZE] = '\0';
	
	while (strncmp(buffer, TOKEN, BUFFER_SIZE)==0)
	{
		recv(*sockIn, buffer, BUFFER_SIZE*sizeof(char), 0);
		GPIO_SET = 1 << 4;
		send(*sockOut, buffer, BUFFER_SIZE*sizeof(char), 0);
		GPIO_CLR = 1 << 4;
	}
}
