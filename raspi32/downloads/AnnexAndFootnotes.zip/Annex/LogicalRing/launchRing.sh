#! /bin/sh
echo "This script doesn't work yet but it could be useful to make it run propperly if an intensive use of the logical ring is needed."
#for i in 1 2 3 4 5 6; do
#    ssh -f pi@node-1-$i "sh -c 'cd logical_ring;nohup ./exec_node_with_GPIO no 192.168.1.$(($i+1)) > /dev/null 2>&1 &'" #this hack allows us to launch a sudo background job via ssh (thanks to the internet)
#    echo "cd logical_ring;./exec_node_without_GPIO no 192.168.1.$((($i+1)%8)) &"
#done
